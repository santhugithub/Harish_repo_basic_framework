URL="http://localhost/login.do"
USER_NAME="admin"
PASSWORD="manager"